
<?php
$servername = "localhost";
$database = "cheatosc_test"; 
$usernamedb = "cheatosc_test";
$password = "Manh010811";
$con = mysqli_connect($servername,$usernamedb,$password,$database);
if (mysqli_connect_errno())
  {
  echo "Không thể kết nối đến MySQL: " . mysqli_connect_error();
  }
?>
